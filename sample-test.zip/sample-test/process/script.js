// Code goes here

var app = angular.module('myapp', []);
app.controller('myCtrl', function(){
  var vm = this;
  
  vm.selectedColors = [];
  vm.colors = [{"id": 1, "color": "Process check 1"},
          {"id": 2, "color": "Process check 2"},
          {"id": 3, "color": "Process check 3"},
          {"id": 4, "color": "Process check 4"}];
          
  vm.toggleColor = function(id){
    var index = vm.selectedColors.indexOf(id);
    if(index == -1) {
      vm.selectedColors.push(id);
    }
    else{
      vm.selectedColors.splice(index, 1);
    } 
  }
  
  vm.selectAllColors = function(){   
    if(vm.chkAll == true)
       vm.selectedColors = vm.colors.map(x=>x.id)
    else
      vm.selectedColors = [];
  }
  
  
  /***** Animals ****/
  vm.selectedAnimals = ['Bear', 'Deer'];
  vm.animals = ['Cat', 'Bear', 'Deer', 'Lion', 'Tiger'];
  vm.toggleAnimal = function(animal){
    var index = vm.selectedAnimals.indexOf(animal);
    if(index == -1) {
      vm.selectedAnimals.push(animal);
    }
    else{
      vm.selectedAnimals.splice(index, 1);
    }
  }
})