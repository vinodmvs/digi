function validationCtrl($scope) {
   var validUsername = "vinod";
   var validEmail = "contactvinnu@gmail.com";
 var clearUsername="";
var clearPassword="";	
   
   $scope.reset = function(){
		$scope.username = clearUsername;
		$scope.email = clearPassword;
   }   
   
   $scope.checkData = function() {
		if ($scope.username != validUsername || $scope.email != validEmail) {
			alert("The data provided do not match with the default owner");
		} else {
			alert("Welcome, Vinod!");
			window.open("process/process.html","_self")
		}
	}
}